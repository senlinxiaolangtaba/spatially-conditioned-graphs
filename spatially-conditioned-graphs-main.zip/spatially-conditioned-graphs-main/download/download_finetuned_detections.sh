#!/bin/bash

bash test2015_finetuned_drg.sh
bash test2015_finetuned_vcl.sh
bash test2015_finetuned_ours.sh